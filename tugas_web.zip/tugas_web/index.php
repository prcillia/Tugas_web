<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyek Sederhana</title>
</head>
<body>
    <h1>Selamat Datang!</h1>
    <p>Nama: [Ruth Maya]</p>
    <p>Nomor Mahasiswa: [22313003]</p>
    <p>Pesan: Selamat datang di proyek web sederhana saya!</p>
</body>
</html>