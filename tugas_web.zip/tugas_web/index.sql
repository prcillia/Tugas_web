<!DOCTYPE html>
<html>
<head>
    <title>Tugas Web Sederhana</title>
</head>
<body>
    <h1>Selamat Datang!</h1>
    <p>Nama: [Ruth Maya] </p>
    <p>Nomor Mahasiswa: [22313003] </p>
    <p>Pesan Selamat Datang: Selamat datang di proyek web sederhana saya!</p>
</body>
</html>